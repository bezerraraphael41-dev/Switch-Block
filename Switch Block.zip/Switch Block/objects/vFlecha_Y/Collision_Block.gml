if (global.Vermelho = false){
	instance_destroy(other)
}