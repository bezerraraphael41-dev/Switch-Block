if (global.Normal != true){
	instance_destroy(other)
}