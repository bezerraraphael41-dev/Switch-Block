if (global.Vermelho != true){
	instance_destroy(other)
}