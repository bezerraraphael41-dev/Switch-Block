if(y == -8 || y == 104){
	if(y = -8 && image_yscale == 1){
		global.Pontos += 1
		instance_destroy()
	}
	if(x == 224 && image_xscale == -1){ 
		global.Pontos += 1
		instance_destroy()
	}
}else{
	y += vsp
}