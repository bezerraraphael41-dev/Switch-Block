if (global.Hard == true){
	vsp = 1.5
}else{
	vsp = 1.35
}

vsp = vsp * image_xscale