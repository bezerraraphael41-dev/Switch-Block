if (global.Azul == false){
	instance_destroy(other)
}