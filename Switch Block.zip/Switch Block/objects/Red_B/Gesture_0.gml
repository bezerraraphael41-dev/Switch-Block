global.Normal = false
global.Vermelho = true
global.Azul = false