room_goto(Game)
global.Hard = false