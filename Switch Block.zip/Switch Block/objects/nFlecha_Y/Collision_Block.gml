if (global.Normal == false){
	instance_destroy(other)
}