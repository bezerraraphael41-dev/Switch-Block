room_goto(Game)
global.Hard = true