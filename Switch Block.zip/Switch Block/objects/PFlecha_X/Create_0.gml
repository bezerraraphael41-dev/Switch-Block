if(global.Hard == true){
	hsp = 2.2
}else{
	hsp = 1.8
}

hsp = hsp * image_xscale