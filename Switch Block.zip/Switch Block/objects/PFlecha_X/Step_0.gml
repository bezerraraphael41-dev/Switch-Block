	
if(x != 391 || x != -7){	
	x += hsp
}
if(x == 391 || x == -7){
	if(x == 391 && image_xscale == 1){
		global.Pontos += 1
		instance_destroy()
	}
	if(x == -7 && image_xscale == -1){ 
		global.Pontos += 1
		instance_destroy()
	}
}