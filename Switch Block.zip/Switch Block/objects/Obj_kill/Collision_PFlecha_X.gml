instance_destroy(other)
global.Sinal = true
alarm[0] = 0.5 * 60