global.Normal = true
global.Vermelho = false
global.Azul = false