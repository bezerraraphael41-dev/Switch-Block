if ( global.Normal == true){
	sprite_index = BlockN
}
if ( global.Azul == true){
	sprite_index = BlockA
}
if ( global.Vermelho == true){
	sprite_index = BlockV
}

flechas_x = PFlecha_X || nFlecha_X || vFlecha_X || aFlecha_X
flechas_y = PFlecha_Y || nFlecha_Y || vFlecha_Y || aFlecha_Y

