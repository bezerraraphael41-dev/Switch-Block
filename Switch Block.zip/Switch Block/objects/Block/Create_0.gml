if (global.Skin == "reversed"){
	BlockN = sBlockRn
	BlockA = sBlockRa
	BlockV = sBlockRv
}else {
	BlockN = sBlockN
	BlockA = sBlockA
	BlockV = sBlockV
}