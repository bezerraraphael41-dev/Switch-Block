if(global.Sinal == true && global.bloqueado == false){
	global.Pontos += 1
	global.Sinal = false
	global.bloqueado = true
	alarm[1] = 60 * 2
}

if (!instance_exists(Block)) {
	room_goto(Menu);
}
