global.Pontos = 0;
global.ultimo_lado = -1; // Começa sem um último lado definido
global.bloqueado = false


// Dispara o primeiro alarme para spawnar a primeira flecha em 2 segundos (120 frames)
alarm[0] = 120;