draw_set_font(Font1)
draw_set_color(c_black)

draw_set_halign(fa_right);
draw_set_valign(fa_top); 

draw_text(150, 32, "Pontos: " + string(global.Pontos));