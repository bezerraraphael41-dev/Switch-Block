// 1. Só spawna flechas se NÃO houver nenhuma flecha na tela
if (instance_number(PFlecha_X) == 0 && instance_number(PFlecha_Y) == 0) {
    
    // Sorteia um lado (0 a 3)
    var _lado = irandom(3);

    // Garante que não repete o mesmo lado da flecha anterior
    if (variable_global_exists("ultimo_lado")) {
        while (_lado == global.ultimo_lado) {
            _lado = irandom(3);
        }
    }
    global.ultimo_lado = _lado;

    // Sorteia a cor/tipo da flecha ('n' = normal, 'v' = vermelha, 'a' = azul)
    var _cor = choose("n", "v", "a");

    var _xx = 0;
    var _yy = 0;
    var _obj = noone;

    // --- LADO 0: Cima ---
    if (_lado == 0) {
        _xx = room_width / 2;
        _yy = -32;
        
        if (_cor == "n")      { _obj = nFlecha_Y; }
        else if (_cor == "v") { _obj = vFlecha_Y; }
        else if (_cor == "a") { _obj = aFlecha_Y; }
    }
    // --- LADO 1: Baixo ---
    else if (_lado == 1) {
        _xx = room_width / 2;
        _yy = room_height + 32;
        
        if (_cor == "n")      { _obj = nFlecha_Y; }
        else if (_cor == "v") { _obj = vFlecha_Y; }
        else if (_cor == "a") { _obj = aFlecha_Y; }
    }
    // --- LADO 2: Esquerda ---
    else if (_lado == 2) {
        _xx = -32;
        _yy = room_height / 2;
        
        if (_cor == "n")      { _obj = nFlecha_X; }
        else if (_cor == "v") { _obj = vFlecha_X; }
        else if (_cor == "a") { _obj = aFlecha_X; }
    }
    // --- LADO 3: Direita ---
    else if (_lado == 3) {
        _xx = room_width + 32;
        _yy = room_height / 2;
        
        if (_cor == "n")      { _obj = nFlecha_X; }
        else if (_cor == "v") { _obj = vFlecha_X; }
        else if (_cor == "a") { _obj = aFlecha_X; }
    }
	
	// Cria a flecha mantendo o tamanho original do sprite (sem mexer em escala)
    objeto_criado = instance_create_layer(_xx, _yy, "OBJs", _obj);
	
	if(_lado == 0){
		objeto_criado.image_yscale = -1
	}
	if(_lado == 3){
		objeto_criado.image_xscale = -1
	}

    
}

// Reinicia o alarme para checar novamente em breve (ex: a cada 30 frames)
alarm[0] = 30;