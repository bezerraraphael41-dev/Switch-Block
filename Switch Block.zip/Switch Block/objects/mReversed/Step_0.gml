if (global.Skin == "reversed"){
	image_index = 1
}else{
	image_index = 0
}