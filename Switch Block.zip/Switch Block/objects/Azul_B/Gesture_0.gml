global.Normal = false
global.Vermelho = false
global.Azul = true