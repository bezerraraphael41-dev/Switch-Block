global.Normal = true
global.Azul = false
global.Vermelho = false

global.Sinal = false
