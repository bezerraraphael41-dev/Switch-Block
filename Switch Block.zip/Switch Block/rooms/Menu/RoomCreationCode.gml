window_center()

if (!variable_global_exists("Skins") && !variable_global_exists("Skin") && !variable_global_exists("Novo")){
	global.Skins = ["normal"]
	global.Skin = "normal"
	global.Novo = false
}